
HOW TO BUILD APK USING GITHUB

1. Upload this ZIP to a new GitHub repository
2. Push files to main branch
3. Open GitHub > Actions
4. Run workflow: Android APK Build
5. Download APK from Artifacts

APK PATH:
app/build/outputs/apk/debug/app-debug.apk
