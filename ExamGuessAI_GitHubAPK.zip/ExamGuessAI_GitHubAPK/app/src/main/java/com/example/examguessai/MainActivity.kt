
package com.example.examguessai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private val apiKey = "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"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            var className by remember { mutableStateOf("") }
            var subject by remember { mutableStateOf("") }
            var chapter by remember { mutableStateOf("") }
            var output by remember { mutableStateOf("") }

            MaterialTheme {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {

                    OutlinedTextField(
                        value = className,
                        onValueChange = { className = it },
                        label = { Text("Class") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = chapter,
                        onValueChange = { chapter = it },
                        label = { Text("Chapter") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {

                            CoroutineScope(Dispatchers.IO).launch {

                                output = generatePaper(
                                    apiKey,
                                    className,
                                    subject,
                                    chapter
                                )
                            }

                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Generate AI Paper")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(output)
                }
            }
        }
    }
}

suspend fun generatePaper(
    apiKey: String,
    className: String,
    subject: String,
    chapter: String
): String {

    return withContext(Dispatchers.IO) {

        try {

            val client = OkHttpClient()

            val prompt = "Generate exam paper for $className $subject chapter $chapter"

            val messages = JSONArray()

            val msg = JSONObject()
            msg.put("role", "user")
            msg.put("content", prompt)

            messages.put(msg)

            val bodyJson = JSONObject()
            bodyJson.put("model", "llama3-8b-8192")
            bodyJson.put("messages", messages)

            val body = RequestBody.create(
                MediaType.parse("application/json"),
                bodyJson.toString()
            )

            val request = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            val response = client.newCall(request).execute()

            val responseText = response.body()?.string() ?: ""

            val json = JSONObject(responseText)

            json
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")

        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}
